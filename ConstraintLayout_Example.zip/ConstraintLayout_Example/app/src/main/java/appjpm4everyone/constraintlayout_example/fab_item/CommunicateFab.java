package appjpm4everyone.constraintlayout_example.fab_item;

public interface CommunicateFab {
    void onClickFab(float xPos, float yPos);
}
